!(function () {
  var e,
    t,
    a,
    o,
    n,
    r = {
      5977: function (e, t, a) {
        "use strict";
        a.d(t, {
          r0: function () {
            return c;
          },
          fT: function () {
            return m;
          },
          Ze: function () {
            return s;
          },
          cU: function () {
            return i;
          },
          yt: function () {
            return l;
          },
          Tw: function () {
            return d;
          },
          wZ: function () {
            return u;
          },
        });
        var o = a(9669);
        const n = a.n(o)().create({ baseURL: "/apis", timeout: 2e4 });
        n.interceptors.response.use(
          (e) => {
            const { code: t, msg: a, data: o } = e.data;
            return 1e3 === t ? ((o.code = t), o) : Promise.reject(new Error(a));
          },
          (e) => Promise.reject(e)
        );
        var r = n;
        const i = (e) =>
            r({
              url: "/mobile/game/getHomeGameByRecent",
              method: "POST",
              data: e,
            }),
          s = (e) =>
            r({
              url: "/mobile/game/getHomeGameByRecommend",
              method: "POST",
              data: e,
            }),
          l = (e) =>
            r({
              url: "/mobile/game/getHomeGameByPersonal",
              method: "POST",
              data: e,
            }),
          u = (e) =>
            r({ url: "/mobile/game/getVoById", method: "POST", data: e }),
          d = (e) =>
            r({
              url: "/mobile/game/getReviewByGameId",
              method: "POST",
              data: e,
            }),
          c = (e) =>
            r({ url: "/mobile/game/addHelpNum", method: "POST", data: e }),
          m = (e) =>
            r({ url: "/mobile/game/addPointNum", method: "POST", data: e });
      },
      6726: function (e, t, a) {
        "use strict";
        a.r(t),
          (t.default = {
            based: "based on your recent activity",
            tit: "Advertising",
            tit2: "Recommend to You",
            tit3: "Personalized recommendations",
            purchases: "In app purchases",
            comments: "comments",
            downloads: "downloads",
            text: "Over",
            text2: "years old",
            install: "Install",
            introduction: "Game Introduction",
            update: "Update date",
            security: "Data Security",
            share: "No data is shared with third parties",
            encipher: "Data is encrypted during transmission",
            del: "You can ask the developer to delete the data",
            scoring: "Scoring and evaluation",
            ratings: "Ratings and reviews have been verified",
            reviews: "reviews",
            view: "View all reviews",
            developer: "Developer Contact Information",
            similar: "Similar games",
            rating: "Rating calculation method",
            txt: "Ratings are based on recent reviews from users in your area using the same type of device as you.",
            method: "Rating calculation method",
            gambling: "gambling",
            shared: "User interaction, shared location, digital goods purchase",
            txt23: "Google Play",
            txt3: "Play Pass",
            txt4: "Play Points",
            txt5: "Gift vouchers",
            txt6: "Redeem",
            txt7: "Refund policy",
            txt8: "Children and family",
            txt9: "Family Guide",
            txt10: "Family Sharing",
            txt11: "Terms of Service",
            txt12: "Privacy",
            txt13: "About Google Play",
            txt14: "Developers",
            txt15: "Google Store",
            txt16: "All prices include Tax",
            txt17: "Brazil (Portuguese)",
            txt18: "Games",
            txt19: "Apps",
            txt20: "Movies",
            txt21: "Books",
            txt22: "Children",
            valley: "Stardew Valley",
            ssoring: "Scoring and evaluation",
            all: "All",
            star: "star",
            most: "Most Relevant",
            txt2: "No more",
            gotit: "Got it",
            person: "person found the comment helpful",
            did: "Did you find this review helpful?",
            yes: "yes",
            no: "no",
          });
      },
      45: function (e, t, a) {
        "use strict";
        a.r(t),
          a.d(t, {
            default: function () {
              return u;
            },
            loadLanguageAsync: function () {
              return l;
            },
          });
        a(7658);
        var o = a(8552);
        const n = (() => {
            let e = "en",
              t =
                "Netscape" == navigator.appName
                  ? navigator.language
                  : navigator.browserLanguage;
            return (
              t.indexOf("pt") > -1
                ? (e = "pt")
                : t.indexOf("en") > -1 && (e = "en"),
              localStorage.getItem("lang") &&
                (e = localStorage.getItem("lang")),
              e
            );
          })(),
          r = (0, o.o)({
            locale: n,
            fallbackLocale: n,
            legacy: !1,
            messages: { [n]: a(8937)(`./${n}.js`).default },
          }),
          i = [n],
          s = (e) => ((r.locale = e), localStorage.setItem("lang", e), e),
          l = async (e) => {
            if (r.locale === e) return Promise.resolve(s(e));
            if (i.includes(e)) return Promise.resolve(s(e));
            const t = await a(7137)(`./${e}.js`);
            return r.setLocaleMessage(e, t.default), i.push(e), s(e);
          };
        var u = r;
      },
      5955: function (e, t, a) {
        "use strict";
        a.r(t),
          (t.default = {
            based: "com base em sua atividade recente",
            tit: "Publicidade",
            tit2: "Recomende para você",
            tit3: "Recomendações personalizadas",
            purchases: "Compras em aplicativos",
            comments: "comentários",
            downloads: "downloads",
            text: "Sobre",
            text2: "anos",
            install: "Instalar",
            introduction: "Introdução ao jogo",
            update: "Data de atualização",
            security: "Segurança de Dados",
            share: "Nenhum dado é compartilhado com terceiros",
            encipher: "Os dados são criptografados durante a transmissão",
            del: "Você pode pedir ao desenvolvedor para excluir os dados",
            scoring: "Pontuação e avaliação",
            ratings: "Avaliações e comentários foram verificados",
            reviews: "comentários",
            view: "Ver todos os comentários",
            developer: "Informações de contato do desenvolvedor",
            similar: "Jogos semelhantes",
            rating: "Método de cálculo de classificação",
            txt: "As classificações são baseadas em comentários recentes de usuários em sua área que usam o mesmo tipo de dispositivo que você.",
            method: "Método de cálculo de classificação",
            gambling: "jogos de azar",
            shared:
              "Interação do usuário, localização compartilhada, compra de produtos digitais",
            txt23: "Google Play",
            txt3: "Play Pass",
            txt4: "Play Points",
            txt5: "Vales-presente",
            txt6: "Resgatar",
            txt7: "Política de reembolso",
            txt8: "Crianças e família",
            txt9: "Guia para a família",
            txt10: "Compartilhamento em família",
            txt11: "Termos de Serviço",
            txt12: "Privacidade",
            txt13: "Sobre o Google Play",
            txt14: "Desenvolvedores",
            txt15: "Google Store",
            txt16: "Todos os preços incluem Tributo.",
            txt17: "Brasil (Português)",
            txt18: "Jogos",
            txt19: "Apps",
            txt20: "Filmes",
            txt21: "Livros",
            txt22: "Crianças",
            valley: "Stardew Valley",
            ssoring: "Pontuação e avaliação",
            all: "Todos",
            star: "estrela",
            most: "Mais relevante",
            txt2: "Não mais",
            gotit: "Entendi",
            person: "a pessoa achou o comentário útil",
            did: "Você achou esta avaliação útil?",
            yes: "Sim",
            no: "não",
          });
      },
      9957: function (e, t, a) {
        "use strict";
        var o = a(9963),
          n = a(6252);
        var r = { name: "App", components: {} },
          i = a(3744);
        var s = (0, i.Z)(r, [
            [
              "render",
              function (e, t, a, o, r, i) {
                const s = (0, n.up)("router-view");
                return (0, n.wg)(), (0, n.j4)(s);
              },
            ],
          ]),
          l = a(2201),
          u = a(3577),
          d = a(2262),
          c = a(5977);
        const m = (e) => (
            (0, n.dD)("data-v-22db399e"), (e = e()), (0, n.Cn)(), e
          ),
          v = { class: "head" },
          f = { class: "game" },
          g = ["src"],
          p = { class: "dow" },
          h = { class: "tit" },
          y = m(() => (0, n._)("span", { class: "tip" }, "3.0", -1)),
          b = m(() =>
            (0, n._)("span", { class: "iconfont icon-xingxing" }, null, -1)
          ),
          x = { class: "text" },
          w = { class: "filter" },
          A = { class: "most" },
          _ = { class: "txt" },
          S = { class: "right" },
          O = { class: "txt" },
          P = m(() =>
            (0, n._)(
              "img",
              {
                src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwAQMAAABtzGvEAAAABlBMVEUAAABkZWZW4oG8AAAAAXRSTlMAQObYZgAAABxJREFUGNNjoAn4DwQfsFIkmoKDIsmUD9gp2gAAIy8nYTOOOWIAAAAASUVORK5CYII=",
                alt: "",
              },
              null,
              -1
            )
          ),
          C = { class: "reviewAll" };
        var k = {
          __name: "more-comments",
          setup(e) {
            const t = (0, n.RC)(() => a.e(605).then(a.bind(a, 8605))),
              o = (0, l.tv)(),
              r = (0, l.yj)(),
              i = (0, d.iH)(""),
              s = (0, d.iH)(!1),
              m = (0, d.iH)(!1),
              k = (0, d.iH)(0),
              j = (0, d.iH)([]),
              T = (0, d.iH)(0),
              G = (0, d.qj)({
                page: 1,
                pageSize: 10,
                gameId: JSON.parse(r.query.gameId),
                reviewGrade: 0,
              }),
              N = async () => {
                i.value = r.query;
                const e = await (0, c.Tw)(G);
                (k.value = e.total || 0),
                  (j.value = j.value.concat(e.records || []));
              },
              I = async () => {
                G.page < k.value && (G.page++, await N()),
                  (s.value = !1),
                  G.page >= k.value && (m.value = !0);
              },
              D = (e) => {
                (G.reviewGrade = e), (T.value = e), (j.value = []), N();
              },
              E = () => {
                o.go(-1);
              };
            return (
              N(),
              (e, a) => {
                const o = (0, n.up)("van-icon"),
                  r = (0, n.up)("van-list");
                return (
                  (0, n.wg)(),
                  (0, n.iD)(
                    n.HY,
                    null,
                    [
                      (0, n._)("div", v, [
                        (0, n.Wm)(o, {
                          onClick: E,
                          name: "arrow-left",
                          size: "24",
                        }),
                        (0, n._)("div", f, [
                          (0, n._)(
                            "img",
                            { src: i.value.gameLogo, alt: "" },
                            null,
                            8,
                            g
                          ),
                          (0, n._)("div", p, [
                            (0, n._)("div", h, [
                              (0, n.Uk)((0, u.zw)(e.$t("valley")), 1),
                              y,
                              b,
                            ]),
                            (0, n._)("div", x, (0, u.zw)(e.$t("ssoring")), 1),
                          ]),
                        ]),
                      ]),
                      (0, n._)("div", w, [
                        (0, n._)(
                          "div",
                          {
                            onClick: a[0] || (a[0] = (e) => D(0)),
                            class: (0, u.C_)(0 == T.value ? "active" : ""),
                          },
                          (0, u.zw)(e.$t("all")),
                          3
                        ),
                        (0, n._)(
                          "div",
                          {
                            onClick: a[1] || (a[1] = (e) => D(5)),
                            class: (0, u.C_)(5 == T.value ? "active" : ""),
                          },
                          "5 " + (0, u.zw)(e.$t("star")),
                          3
                        ),
                        (0, n._)(
                          "div",
                          {
                            onClick: a[2] || (a[2] = (e) => D(4)),
                            class: (0, u.C_)(4 == T.value ? "active" : ""),
                          },
                          "4 " + (0, u.zw)(e.$t("star")),
                          3
                        ),
                        (0, n._)(
                          "div",
                          {
                            onClick: a[3] || (a[3] = (e) => D(3)),
                            class: (0, u.C_)(3 == T.value ? "active" : ""),
                          },
                          "3 " + (0, u.zw)(e.$t("star")),
                          3
                        ),
                        (0, n._)(
                          "div",
                          {
                            onClick: a[4] || (a[4] = (e) => D(2)),
                            class: (0, u.C_)(2 == T.value ? "active" : ""),
                          },
                          "2 " + (0, u.zw)(e.$t("star")),
                          3
                        ),
                        (0, n._)(
                          "div",
                          {
                            onClick: a[5] || (a[5] = (e) => D(1)),
                            class: (0, u.C_)(1 == T.value ? "active" : ""),
                          },
                          "1 " + (0, u.zw)(e.$t("star")),
                          3
                        ),
                      ]),
                      (0, n._)("div", A, [
                        (0, n._)("div", _, (0, u.zw)(e.$t("all")), 1),
                        (0, n._)("div", S, [
                          (0, n._)("div", O, (0, u.zw)(e.$t("most")), 1),
                          (0, n.Uk)(),
                          P,
                        ]),
                      ]),
                      (0, n._)("div", C, [
                        (0, n.Wm)(
                          r,
                          {
                            loading: s.value,
                            "onUpdate:loading":
                              a[6] || (a[6] = (e) => (s.value = e)),
                            finished: m.value,
                            "immediate-check": !0,
                            "finished-text": e.$t("txt2"),
                            onLoad: I,
                            offset: 30,
                          },
                          {
                            default: (0, n.w5)(() => [
                              ((0, n.wg)(!0),
                              (0, n.iD)(
                                n.HY,
                                null,
                                (0, n.Ko)(
                                  j.value,
                                  (e, a) => (
                                    (0, n.wg)(),
                                    (0, n.iD)("div", { key: a }, [
                                      (0, n.Wm)(
                                        (0, d.SU)(t),
                                        { data: e },
                                        null,
                                        8,
                                        ["data"]
                                      ),
                                    ])
                                  )
                                ),
                                128
                              )),
                            ]),
                            _: 1,
                          },
                          8,
                          ["loading", "finished", "finished-text"]
                        ),
                      ]),
                    ],
                    64
                  )
                );
              }
            );
          },
        };
        const j = [
          {
            path: "/home",
            name: "home",
            component: () => a.e(762).then(a.bind(a, 4762)),
          },
          {
            path: "/",
            name: "details",
            component: () => a.e(532).then(a.bind(a, 7532)),
          },
          {
            path: "/moreComments",
            name: "moreComments",
            component: (0, i.Z)(k, [["__scopeId", "data-v-22db399e"]]),
          },
        ];
        var T = (0, l.p7)({
            history: (0, l.PO)(),
            scrollBehavior(e, t, a) {
              return a || { top: 0 };
            },
            routes: j,
          }),
          G = a(45),
          N = (a(5110), a(1786)),
          I = a(5267),
          D = a(8498),
          E = a(3013),
          z = a(6907),
          R = a(6898),
          U = a(2339);
        const B = (0, o.ri)(s);
        B.use(T),
          B.use(N.Vq),
          B.use(I.TS),
          B.use(D.FN),
          B.use(E.aV),
          B.use(z.zx),
          B.use(R.JO),
          B.use(U.j8),
          B.use(G.default),
          B.mount("#app");
      },
      7137: function (e, t, a) {
        var o = { "./en.js": 6726, "./index.js": 45, "./pt.js": 5955 };
        function n(e) {
          return Promise.resolve().then(function () {
            if (!a.o(o, e)) {
              var t = new Error("Cannot find module '" + e + "'");
              throw ((t.code = "MODULE_NOT_FOUND"), t);
            }
            return a(o[e]);
          });
        }
        (n.keys = function () {
          return Object.keys(o);
        }),
          (n.id = 7137),
          (e.exports = n);
      },
      8937: function (e, t, a) {
        var o = { "./en.js": 6726, "./index.js": 45, "./pt.js": 5955 };
        function n(e) {
          var t = r(e);
          return a(t);
        }
        function r(e) {
          if (!a.o(o, e)) {
            var t = new Error("Cannot find module '" + e + "'");
            throw ((t.code = "MODULE_NOT_FOUND"), t);
          }
          return o[e];
        }
        (n.keys = function () {
          return Object.keys(o);
        }),
          (n.resolve = r),
          (e.exports = n),
          (n.id = 8937);
      },
    },
    i = {};
  function s(e) {
    var t = i[e];
    if (void 0 !== t) return t.exports;
    var a = (i[e] = { exports: {} });
    return r[e](a, a.exports, s), a.exports;
  }
  (s.m = r),
    (e = []),
    (s.O = function (t, a, o, n) {
      if (!a) {
        var r = 1 / 0;
        for (d = 0; d < e.length; d++) {
          (a = e[d][0]), (o = e[d][1]), (n = e[d][2]);
          for (var i = !0, l = 0; l < a.length; l++)
            (!1 & n || r >= n) &&
            Object.keys(s.O).every(function (e) {
              return s.O[e](a[l]);
            })
              ? a.splice(l--, 1)
              : ((i = !1), n < r && (r = n));
          if (i) {
            e.splice(d--, 1);
            var u = o();
            void 0 !== u && (t = u);
          }
        }
        return t;
      }
      n = n || 0;
      for (var d = e.length; d > 0 && e[d - 1][2] > n; d--) e[d] = e[d - 1];
      e[d] = [a, o, n];
    }),
    (s.n = function (e) {
      var t =
        e && e.__esModule
          ? function () {
              return e.default;
            }
          : function () {
              return e;
            };
      return s.d(t, { a: t }), t;
    }),
    (s.d = function (e, t) {
      for (var a in t)
        s.o(t, a) &&
          !s.o(e, a) &&
          Object.defineProperty(e, a, { enumerable: !0, get: t[a] });
    }),
    (s.f = {}),
    (s.e = function (e) {
      return Promise.all(
        Object.keys(s.f).reduce(function (t, a) {
          return s.f[a](e, t), t;
        }, [])
      );
    }),
    (s.u = function (e) {
      return (
        "js/" +
        e +
        "." +
        { 532: "cba8fc11", 605: "d4e34dfc", 762: "0b07b6de", 985: "22819c98" }[
          e
        ] +
        ".js"
      );
    }),
    (s.miniCssF = function (e) {
      return (
        "css/" +
        e +
        "." +
        { 532: "788901d7", 605: "b4b8128b", 762: "d6fdd8c2", 985: "64f4b7e3" }[
          e
        ] +
        ".css"
      );
    }),
    (s.g = (function () {
      if ("object" == typeof globalThis) return globalThis;
      try {
        return this || new Function("return this")();
      } catch (e) {
        if ("object" == typeof window) return window;
      }
    })()),
    (s.o = function (e, t) {
      return Object.prototype.hasOwnProperty.call(e, t);
    }),
    (t = {}),
    (a = "Game-Shop-H5:"),
    (s.l = function (e, o, n, r) {
      if (t[e]) t[e].push(o);
      else {
        var i, l;
        if (void 0 !== n)
          for (
            var u = document.getElementsByTagName("script"), d = 0;
            d < u.length;
            d++
          ) {
            var c = u[d];
            if (
              c.getAttribute("src") == e ||
              c.getAttribute("data-webpack") == a + n
            ) {
              i = c;
              break;
            }
          }
        i ||
          ((l = !0),
          ((i = document.createElement("script")).charset = "utf-8"),
          (i.timeout = 120),
          s.nc && i.setAttribute("nonce", s.nc),
          i.setAttribute("data-webpack", a + n),
          (i.src = e)),
          (t[e] = [o]);
        var m = function (a, o) {
            (i.onerror = i.onload = null), clearTimeout(v);
            var n = t[e];
            if (
              (delete t[e],
              i.parentNode && i.parentNode.removeChild(i),
              n &&
                n.forEach(function (e) {
                  return e(o);
                }),
              a)
            )
              return a(o);
          },
          v = setTimeout(
            m.bind(null, void 0, { type: "timeout", target: i }),
            12e4
          );
        (i.onerror = m.bind(null, i.onerror)),
          (i.onload = m.bind(null, i.onload)),
          l && document.head.appendChild(i);
      }
    }),
    (s.r = function (e) {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(e, "__esModule", { value: !0 });
    }),
    (s.p = "/"),
    (o = function (e) {
      return new Promise(function (t, a) {
        var o = s.miniCssF(e),
          n = s.p + o;
        if (
          (function (e, t) {
            for (
              var a = document.getElementsByTagName("link"), o = 0;
              o < a.length;
              o++
            ) {
              var n =
                (i = a[o]).getAttribute("data-href") || i.getAttribute("href");
              if ("stylesheet" === i.rel && (n === e || n === t)) return i;
            }
            var r = document.getElementsByTagName("style");
            for (o = 0; o < r.length; o++) {
              var i;
              if ((n = (i = r[o]).getAttribute("data-href")) === e || n === t)
                return i;
            }
          })(o, n)
        )
          return t();
        !(function (e, t, a, o) {
          var n = document.createElement("link");
          (n.rel = "stylesheet"),
            (n.type = "text/css"),
            (n.onerror = n.onload =
              function (r) {
                if (((n.onerror = n.onload = null), "load" === r.type)) a();
                else {
                  var i = r && ("load" === r.type ? "missing" : r.type),
                    s = (r && r.target && r.target.href) || t,
                    l = new Error(
                      "Loading CSS chunk " + e + " failed.\n(" + s + ")"
                    );
                  (l.code = "CSS_CHUNK_LOAD_FAILED"),
                    (l.type = i),
                    (l.request = s),
                    n.parentNode.removeChild(n),
                    o(l);
                }
              }),
            (n.href = t),
            document.head.appendChild(n);
        })(e, n, t, a);
      });
    }),
    (n = { 143: 0 }),
    (s.f.miniCss = function (e, t) {
      n[e]
        ? t.push(n[e])
        : 0 !== n[e] &&
          { 532: 1, 605: 1, 762: 1, 985: 1 }[e] &&
          t.push(
            (n[e] = o(e).then(
              function () {
                n[e] = 0;
              },
              function (t) {
                throw (delete n[e], t);
              }
            ))
          );
    }),
    (function () {
      var e = { 143: 0 };
      (s.f.j = function (t, a) {
        var o = s.o(e, t) ? e[t] : void 0;
        if (0 !== o)
          if (o) a.push(o[2]);
          else {
            var n = new Promise(function (a, n) {
              o = e[t] = [a, n];
            });
            a.push((o[2] = n));
            var r = s.p + s.u(t),
              i = new Error();
            s.l(
              r,
              function (a) {
                if (s.o(e, t) && (0 !== (o = e[t]) && (e[t] = void 0), o)) {
                  var n = a && ("load" === a.type ? "missing" : a.type),
                    r = a && a.target && a.target.src;
                  (i.message =
                    "Loading chunk " + t + " failed.\n(" + n + ": " + r + ")"),
                    (i.name = "ChunkLoadError"),
                    (i.type = n),
                    (i.request = r),
                    o[1](i);
                }
              },
              "chunk-" + t,
              t
            );
          }
      }),
        (s.O.j = function (t) {
          return 0 === e[t];
        });
      var t = function (t, a) {
          var o,
            n,
            r = a[0],
            i = a[1],
            l = a[2],
            u = 0;
          if (
            r.some(function (t) {
              return 0 !== e[t];
            })
          ) {
            for (o in i) s.o(i, o) && (s.m[o] = i[o]);
            if (l) var d = l(s);
          }
          for (t && t(a); u < r.length; u++)
            (n = r[u]), s.o(e, n) && e[n] && e[n][0](), (e[n] = 0);
          return s.O(d);
        },
        a = (self.webpackChunkGame_Shop_H5 =
          self.webpackChunkGame_Shop_H5 || []);
      a.forEach(t.bind(null, 0)), (a.push = t.bind(null, a.push.bind(a)));
    })();
  var l = s.O(void 0, [998], function () {
    return s(9957);
  });
  l = s.O(l);
})();
